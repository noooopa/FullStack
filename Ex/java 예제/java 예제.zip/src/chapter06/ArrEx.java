package chapter06;

public class ArrEx {

	public static void main(String[] args) {
		
		int[] arrInt;
		int arrInt2[];
		
		double[] arrDouble;
		String[] arrString;
		

	}

}
