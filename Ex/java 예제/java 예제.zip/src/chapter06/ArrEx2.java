package chapter06;

public class ArrEx2 {

	public static void main(String[] args) {
		
		int[] arrInt = new int[5]; // 길이가 5개인 배열 객체 생성
		
		System.out.println(arrInt[0]);

	}

}
