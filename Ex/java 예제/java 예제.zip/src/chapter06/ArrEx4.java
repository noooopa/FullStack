package chapter06;

public class ArrEx4 {

	public static void main(String[] args) {
		
		String[] arrStr = new String[5];
		
//		System.out.println(arrStr[0]);
		
		char[] arrChar = new char[3];
		System.out.print(arrChar[0]*2);
		System.out.print('\u0000'*2);
		
	}

}
