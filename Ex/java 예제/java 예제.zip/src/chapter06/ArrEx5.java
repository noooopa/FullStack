package chapter06;

public class ArrEx5 {

	public static void main(String[] args) {
		
		String[] arrStr = {"홍길동", "이순신", "김유신"};
		
		
	}

}
