package chapter06;

public class ArrEx1 {

	public static void main(String[] args) {
		
		int[] arrInt;
		int arrInt2[] = null;
		
		//System.out.println(arrInt[0]); // 에러 발생
		System.out.println(arrInt2[0]); // 에러 발생하지 않음
		

	}

}
