package chapter06;

public class ReferenceType {

	public static void main(String[] args) {
		
		String name1 = "홍길동";
		String name2 = "홍길동";
		
		System.out.println(name1 == name2);

	}

}
