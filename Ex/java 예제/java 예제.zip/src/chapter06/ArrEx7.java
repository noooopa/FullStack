package chapter06;

public class ArrEx7 {

	public static void main(String[] args) {
		
		String[] arrStr = {"홍길동", "이순신", "김유신"};
		
		for (int i=0; i<arrStr.length; i++) {
			System.out.println(arrStr[i]);
		}
		
	}

}
