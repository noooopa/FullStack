package chapter06;

public class Excercise1 {

	public static void main(String[] args) {
		
//		int[] arr = {1,2,3};
		
//		int arr[3];
		
//		int[] arr = new int[3];
		
//		int arr[3] = new int[3]; 
		
	}

}
