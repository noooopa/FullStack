package chapter06;

public class ArrEx3 {

	public static void main(String[] args) {
		
		int[] arrInt = new int[5]; // 길이가 5개인 배열 객체 생성
		
		arrInt[0] = 1;
		arrInt[1] = 2;
		arrInt[2] = 3;
		arrInt[3] = 4;
		arrInt[4] = 5;
		
	}

}
