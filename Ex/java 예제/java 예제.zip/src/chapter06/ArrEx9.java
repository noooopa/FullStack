package chapter06;

public class ArrEx9 {

	public static void main(String[] args) {
		
		System.out.println("첫번째 값 : "+args[0]);
		System.out.println("두번째 값 : "+args[1]);
		
	}

}
