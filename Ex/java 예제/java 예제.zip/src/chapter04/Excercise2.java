package chapter04;

public class Excercise2 {

	public static void main(String[] args) {
		
		int var = 7 - 1 * 20 / 5;
		System.out.println(var);
	}
}
