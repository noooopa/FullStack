package chapter04;

public class OpEx3 {

	public static void main(String[] args) {
		
//		int a = 10;
//		int b = 10;
//		
//		++a; // 전위연산
//		b++; // 후위연산
//		
//		System.out.println(a);
//		System.out.println(b);
		
//		int a = 10;
//		int b = ++a;
//		
//		System.out.println("전위연산 결과 : "+b);
//		
//		int x = 10;
//		int y = x++;
//		System.out.println("후위연산 결과 : "+y);
//		System.out.println("x : "+x);
		
		int a = 10;
		a++;
		System.out.println("a++ : " + a);
		int b = 10;
		b += 1;
		System.out.println("b += 1 : " + b);
		int c = 10;
		c = c + 1;
		System.out.println("c = c + 1 : " + c);
		
		

	}

}
