package chapter04;

public class OpEx2_1 {

	public static void main(String[] args) {
		
		int a = 5;
		
		System.out.println("+a = " + +a);
		System.out.println("-a = " + -a);
		
		a = -5;
		
		System.out.println("+a = " + +a);
		System.out.println("-a = " + -a);
		
	}

}
