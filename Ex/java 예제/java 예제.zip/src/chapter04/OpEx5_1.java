package chapter04;

public class OpEx5_1 {

	public static void main(String[] args) {

		int a = 10;
		int b = 5;
		
		// 모두 false
		System.out.println(a == b && a > b);
		System.out.println(a == b & a > b);
		
		
		
	}

}
