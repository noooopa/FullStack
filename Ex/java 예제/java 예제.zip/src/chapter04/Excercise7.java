package chapter04;

public class Excercise7 {

	public static void main(String[] args) {
		
		int number = 1234;
		int result = number / 100 * 100;
		System.out.println(result);
		
		int result2 = number - number % 100;
		System.out.println(result2);
		
	}
}
