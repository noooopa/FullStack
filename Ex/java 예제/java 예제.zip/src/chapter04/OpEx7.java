package chapter04;

public class OpEx7 {

	public static void main(String[] args) {
		
		int score = 80;
		String pass = score >= 60 ? "합격 " : "불합격";
		System.out.println(pass);
		
	}

}
