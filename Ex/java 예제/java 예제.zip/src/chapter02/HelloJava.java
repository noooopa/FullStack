package chapter02;

public class HelloJava {
	
	public static void main(String[] args) {
		
		// System.out.println("Hello Java");
		
		/*
		 * Hello Java를 출력하는 실행문을 주석처리 하고
		 * 아래 안녕 자바라고 출력되는 실행문을 추가
		 */
		
		// "안녕 자바"라고 출력되는 실행문
		System.out.println("안녕 자바");
		
		
		System.out.println("Hello Java");System.out.println("안녕 자바");
		
		java.Test t = new java.Test();
		
	}
	
}
