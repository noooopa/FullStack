package chapter02;

public class VarEx {

	public static void main(String[] args) {
//		int a; // 변수 선언
//		a = 10;
		
//		long a = 2200000000L;
//		System.out.println(a);
//		double b = 3.14;
//		boolean c = true;
//		
//		String name = "홍길동";
		
		
//		int a;	// 변수 선언
//		a = 10;	// 변수 초기화
//		
//		int b = 10; // 변수 선언과 초기화 동시에
//		
//		int A;
//		
//		int 변수;
//		변수 = 10;
//		
//		String name;	// 변수 선언
//		name = "홍길동";	// 변수 초기화
//		
//		String name2 = "홍길동"; // 선언과 동시에 초기화
//		String name3 = null;	// null값으로 선언
//		String name4 = "";
//		
//		System.out.println("name3="+name3);
//		System.out.println("name4="+name4);
		
//		String a = "1";
//		String b = "1.5";
//		String c = "true";
		
//		final double PI = 3.14;	// 상수 선언
//		PI = 3.141592;			// 상수에 값 변경 시 에러 발생
		
//		int a = 10;
//		
//		if (1==1) {
//			a = 20;
//			int a2 = 10;
//		}
//		a = 30;
//		a2 = 20;
		
		
		int a = 10;
		long b = a;
		System.out.println(b);
		
		double c = 3.14;
		int d = (int)c;
		System.out.println(d);
		
		

	}

}
