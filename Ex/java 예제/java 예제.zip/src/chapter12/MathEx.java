package chapter12;

public class MathEx {

	public static void main(String[] args) {
		
		System.out.println("Math.abs(10)=" + Math.abs(10));
		System.out.println("Math.abs(-10)=" + Math.abs(-10));
		System.out.println("Math.abs(3.1415)=" + Math.abs(3.1415));
		System.out.println("Math.abs(-3.1415)=" + Math.abs( 3.1415));
		System.out.println("Math.ceil(5.4)=" + Math.ceil(5.4));
		System.out.println("Math.ceil(-5.4)=" + Math.ceil(-5.4));
		System.out.println("Math.floor(5.4)=" + Math.floor(5.4));
		System.out.println("Math.floor(-5.4)=" + Math.floor(-5.4));
		System.out.println("Math.max(5,4)=" + Math.max(5,4));
		System.out.println("Math.max(5.4,5.3)=" + Math.max(5.4,5.3));
		System.out.println("Math.min(5,4)=" + Math.min(5,4));
		System.out.println("Math.min(5.4,5.3)=" + Math.min(5.4,5.3));
		System.out.println("Math.random()=" + Math. random());
		System.out.println("Math.rint(5.4)=" + Math.rint(5.4));
		System.out.println("Math.rint(-5.4)=" + Math.rint(-5.4));
		System.out.println("Math.round(5.4)=" + Math.round(5.4));
		System.out.println("Math.round(5.5)=" + Math.round(5.5));

	}

}
