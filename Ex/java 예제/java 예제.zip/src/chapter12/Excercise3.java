package chapter12;

public class Excercise3 {

	public static void main(String[] args) {
		
		String num1 = "100";
		String num2 = "200";
		
		// 코드 작성
		System.out.println("합계:"+(Integer.parseInt(num1)
				                 +Integer.parseInt(num2)));

	}

}
