package chapter12;

import java.util.Date;

public class ToStringDateEx {

	public static void main(String[] args) {
		
		Date now = new Date();
		System.out.println(now);

	}

}
