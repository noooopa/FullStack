package chapter12.string;

public class StringEx6 {
	
	public static void main(String[] args) {
		
		String s1 = "";
		
		System.out.println("s1.length():"+s1.length());
		System.out.println("".equals(s1));

	}

}
