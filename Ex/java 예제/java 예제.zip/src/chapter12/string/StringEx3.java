package chapter12.string;

public class StringEx3 {

	public static void main(String[] args) {
		
		String sum = "";
		
		for (int i=1; i<=5; i++) {
			sum += i;
		}
		System.out.println(sum);

	}

}
