package chapter12;

public class WrapperEx2 {

	public static void main(String[] args) {
		
		System.out.println("정수의 최대값 :" + Integer.MAX_VALUE);
		System.out.println("정수의 최소값 :" + Integer.MIN_VALUE);
		System.out.println("byte의 최대값 :" + Byte.MAX_VALUE);
		System.out.println("byte의 최소값 :" + Byte.MIN_VALUE);
		System.out.println("정수의 사이즈 :" + Integer.SIZE);
		System.out.println("float의 사이즈 :" + Float.SIZE);
		System.out.println("double의 사이즈 :" + Double.SIZE);

	}

}
