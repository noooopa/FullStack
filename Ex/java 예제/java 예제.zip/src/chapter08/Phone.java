package chapter08;

public class Phone {

	String name;
	String color;
	String company;
	
	void call() {
		System.out.println("전화를 건다");
	}
	
	void receive() {
		System.out.println("전화를 받다");
	}
	
}
