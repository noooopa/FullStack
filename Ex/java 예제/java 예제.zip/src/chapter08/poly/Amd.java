package chapter08.poly;

public class Amd extends GraphicCard {

	public void process() {
		System.out.println("AMD 그래픽 처리");
	}
	
}
