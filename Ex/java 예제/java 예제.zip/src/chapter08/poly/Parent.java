package chapter08.poly;

public class Parent {

	String name;
	
	void walk() {
		System.out.println("부모가 걷는다.");
	}
	
	void run() {
		System.out.println("부모가 달린다.");
	}
	
}
