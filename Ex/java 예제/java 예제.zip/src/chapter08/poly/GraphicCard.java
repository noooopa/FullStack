package chapter08.poly;

public class GraphicCard {

	int memory;
	
	public void process() {
		System.out.println("그래픽 처리");
	}
	
}
