package chapter08.poly;

public class Game {

	void display(GraphicCard gc) {
		gc.process();
	}
	
}
