package chapter08.poly;

public class Nvidia extends GraphicCard {

	public void process() {
		System.out.println("Nvidia 그래픽 처리");
	}
	
}
