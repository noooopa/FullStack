package chapter08;

public class Taxi extends Car {
	
	public void go() {
		System.out.println("미터기를 켜고 전진");
	}
}
