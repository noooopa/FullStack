package chapter08;

public class Car {

	String color;
	String name;
	
	public void go() {
		System.out.println("전진");
	}
	
	void back() {
		System.out.println("후진");
	}
}
