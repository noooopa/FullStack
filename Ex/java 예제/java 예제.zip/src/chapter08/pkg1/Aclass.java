package chapter08.pkg1;

public class Aclass {

	protected String varA;
	String varA2;
	
	protected void methodA() {
		System.out.println("methodA");
	}
	
	void methodA2() {
		System.out.println("methodA2");
	}
}
