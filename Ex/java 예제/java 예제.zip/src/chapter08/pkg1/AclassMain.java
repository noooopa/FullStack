package chapter08.pkg1;

public class AclassMain {

	public static void main(String[] args) {
		
		Aclass ac = new Aclass();
		ac.varA = "varA";
		ac.varA2 = "varA2";
		ac.methodA();
		ac.methodA2();
		
	}
}
