package chapter03;

public class PrimitiveType {

	public static void main(String[] args) {
		
		boolean run = true;
		
		
		byte b = 1;
		short s = 10;
		int i = 100;
		long l = 1000l;
		long l2 = 1000L;
		
		

	}

}
