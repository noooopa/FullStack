package chapter03;

public class Excercise {

	public static void main(String[] args) {
		
		//int c = 'A';
		
		
//		int a = 3.14;
//		int b = 3f;
//		float c = 3d;
//		double d = 3L;
		
		double a = 3.141562;
		int b = (int)a;
		System.out.println(b);

	}

}
