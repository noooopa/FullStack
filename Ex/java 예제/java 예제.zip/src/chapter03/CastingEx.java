package chapter03;

public class CastingEx {

	public static void main(String[] args) {
		
		// 자동형변환 예시
		int number = 10;	// int 자료형
		
		long number2 = number;	// 자동형변환 int < long
		
		System.out.println(number2);
		
	}
}