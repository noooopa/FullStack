package chapter03;

public class CharType {

	public static void main(String[] args) {
		
		char a = 'A';
		
		System.out.println("a:"+a);
		
		int b = a;
		System.out.println("b:"+b);
		
		char c = 66;
		System.out.println("c:"+c);
		
		int d = a+b; // 65 + 65
		System.out.println("d:"+d);

	}

}
