package chapter03;

public class FloatDoubleEx {

	public static void main(String[] args) {
		
		float f = 3.141592653589793f;
		double d = 3.141592653589793d;
		
		System.out.println("float : "+f);
		System.out.println("double : "+d);
		
		double d2 = 3.141592653589793; // d 생략가능
		System.out.println("double : "+d2);
	}

}
