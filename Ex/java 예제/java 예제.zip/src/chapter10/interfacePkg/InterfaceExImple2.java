package chapter10.interfacePkg;

public class InterfaceExImple2 implements Outer.InterfaceEx{

	@Override
	public void method() {
		
		System.out.println("InterfaceExImple2 method()");
		
	}

}
