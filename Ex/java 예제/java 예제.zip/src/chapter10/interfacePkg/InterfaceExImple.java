package chapter10.interfacePkg;

public class InterfaceExImple implements Outer.InterfaceEx{

	@Override
	public void method() {
		
		System.out.println("InterfaceExImple method()");
		
	}

}
