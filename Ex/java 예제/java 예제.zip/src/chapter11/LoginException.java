package chapter11;

public class LoginException extends Exception {

	LoginException(String msg) {
		super(msg);
	}
}
