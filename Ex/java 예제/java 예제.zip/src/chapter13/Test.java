package chapter13;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
//		Iterator i = new Iterator<E>() {
//		};

	}

}
