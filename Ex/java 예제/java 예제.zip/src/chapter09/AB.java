package chapter09;

public interface AB extends A {

	void ab();
}
