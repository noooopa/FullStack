package chapter09;

public class Parent {

	public void method2() {
		System.out.println("Parent 클래스의 method2()");
	}
}
