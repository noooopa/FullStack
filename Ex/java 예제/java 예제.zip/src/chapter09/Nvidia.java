package chapter09;

public class Nvidia implements GraphicCard {

	public void process() {
		System.out.println("Nvidia 그래픽 처리");
	}
	
}
