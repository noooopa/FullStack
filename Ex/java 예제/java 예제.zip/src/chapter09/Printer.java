package chapter09;

public interface Printer {

	int INK = 100;
	void print();
	
}
