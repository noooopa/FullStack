package chapter09;

public class AAA implements AA {

	@Override
	public void a() {
		
	}
	
	@Override
	public void aa() {
		
	}

}
