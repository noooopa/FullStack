package chapter09;

public interface AA extends A {

	void aa();
}
