package chapter09;

public interface Fax {

	String FAX_NUMBER = "02-1234-5678";
	void send(String tel);
	void receive(String tel);
	
}
