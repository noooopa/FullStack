package chapter09;

public interface Animal {
	
	void sleep();
}
