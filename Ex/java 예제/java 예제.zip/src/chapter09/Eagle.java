package chapter09;

public class Eagle implements Animal {

	public void sleep() {
		System.out.println("잠을 잔다.");
	}
	
	public void eat() {
		System.out.println("먹는다.");
	}

	
}
