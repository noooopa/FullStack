package chapter09;

public class Amd implements GraphicCard {

	public void process() {
		System.out.println("AMD 그래픽 처리");
	}
	
}
