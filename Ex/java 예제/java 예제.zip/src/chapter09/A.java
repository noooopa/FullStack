package chapter09;

public interface A {

	void a();
}
