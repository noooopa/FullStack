package chapter09;

public interface Scanner {

	void scan();
	
}
