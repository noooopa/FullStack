package chapter09;

public interface ComplexcerInterface extends Printer, Scanner, Fax {

}
