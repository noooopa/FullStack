package chapter09;

public interface GraphicCard {

	String MEMORY = "2G";
	
	public void process();
	
}
