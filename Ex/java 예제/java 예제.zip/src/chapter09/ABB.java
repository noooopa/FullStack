package chapter09;

public class ABB implements AB {

	@Override
	public void a() {
		
	}

	@Override
	public void ab() {
		
	}

}
