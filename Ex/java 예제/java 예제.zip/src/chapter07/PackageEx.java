package chapter07;

public class PackageEx {

	public static void main(String[] args) {
		
		chapter07.test.TestPackage test = new chapter07.test.TestPackage();
		test.method();
		
	}
	
}
