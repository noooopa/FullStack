package chapter07;

public class Member {
	
}
