package chapter07;

public class Car {

	// 필드
	String color;
	String company;
	String type;
	
	// 메서드
	public void go() {
		System.out.println("전진하다.");
	}
	public void back() {
		System.out.println("후진하다.");
	}
}
