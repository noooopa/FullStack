package chapter07;

public class Excercise8 {
	
	public static void main(String[] args) {
		
		String number = "123";
		
		System.out.println("출력값 : " + add(number));
		
	}
	
	public static String add(String number) {
		return number + "456";
	}

}


