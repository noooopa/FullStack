package chapter07;

public class Excercise3 {

}


class Person {
	
	String name;	// 이름
	String gender;	// 성별
	int age;		// 나이
	int height;		// 키
	int weight;		// 몸무게
	
}