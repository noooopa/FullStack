package chapter07.test;

public class TestPackage {

	public void method() {
		System.out.println("chapter.test 패키지의 TestPackage 클래스");
	}
}
