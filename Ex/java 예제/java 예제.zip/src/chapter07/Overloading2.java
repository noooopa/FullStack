package chapter07;

public class Overloading2 {

	public static void main(String[] args) {
		
		System.out.println(1);
		System.out.println(5.5);
		System.out.println((long)100);
		System.out.println("홍길동");
		System.out.println('a');
		System.out.println(true);
		System.out.println(new Overloading2());
		System.out.println(new int[5]);
		
	}

}

